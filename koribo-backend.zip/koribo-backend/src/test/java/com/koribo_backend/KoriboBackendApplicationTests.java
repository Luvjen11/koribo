package com.koribo_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KoriboBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
